const mysql = require('mysql');

const connection = mysql.createConnection({
    host: 'localhost',     
    user: 'root',          
    password: '',          
    database: 'crud_escuelas', 
    port: 3306             
});

connection.connect((err) => {
    if (err) {
        console.error('Error al conectar a MySQL:', err);
        return;
    }
    console.log('Conexión exitosa a la base de datos.');
});

module.exports = connection;
