const express = require('express');
const bodyParser = require('body-parser');
const connection = require('./database/connection');

const app = express();


app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.set('view engine', 'ejs');
app.use(express.static('public'));


app.get('/', (req, res) => {
    connection.query('SELECT * FROM usuarios', (err, results) => {
        if (err) {
            console.error('Error al obtener usuarios:', err);
            return res.status(500).send('Error al obtener usuarios');
        }
        res.render('list', { usuarios: results });
    });
});


app.get('/create', (req, res) => {
    res.render('create');
});


app.post('/create', (req, res) => {
    const { nombre, correo, numero_cuenta, escuela } = req.body;

    if (!nombre || !correo || !numero_cuenta || !escuela) {
        return res.status(400).send('Todos los campos son obligatorios');
    }

    const query = 'INSERT INTO usuarios (nombre, correo, numero_cuenta, escuela) VALUES (?, ?, ?, ?)';
    connection.query(query, [nombre, correo, numero_cuenta, escuela], (err) => {
        if (err) {
            console.error('Error al insertar usuario:', err);
            return res.status(500).send('Error al crear el usuario');
        }
        res.redirect('/');
    });
});


app.get('/edit/:id', (req, res) => {
    const { id } = req.params;
    const query = 'SELECT * FROM usuarios WHERE id = ?';
    connection.query(query, [id], (err, results) => {
        if (err) {
            console.error('Error al obtener usuario:', err);
            return res.status(500).send('Error al obtener el usuario');
        }
        if (results.length === 0) {
            return res.status(404).send('Usuario no encontrado');
        }
        res.render('edit', { usuario: results[0] });
    });
});


app.post('/edit/:id', (req, res) => {
    const { id } = req.params;
    const { nombre, correo, numero_cuenta, escuela } = req.body;

    if (!nombre || !correo || !numero_cuenta || !escuela) {
        return res.status(400).send('Todos los campos son obligatorios');
    }

    const query = 'UPDATE usuarios SET nombre = ?, correo = ?, numero_cuenta = ?, escuela = ? WHERE id = ?';
    connection.query(query, [nombre, correo, numero_cuenta, escuela, id], (err) => {
        if (err) {
            console.error('Error al actualizar usuario:', err);
            return res.status(500).send('Error al actualizar el usuario');
        }
        res.redirect('/');
    });
});


app.get('/delete/:id', (req, res) => {
    const { id } = req.params;
    const query = 'DELETE FROM usuarios WHERE id = ?';
    connection.query(query, [id], (err) => {
        if (err) {
            console.error('Error al eliminar usuario:', err);
            return res.status(500).send('Error al eliminar el usuario');
        }
        res.redirect('/');
    });
});


app.listen(3000, () => {
    console.log('Servidor corriendo en http://localhost:3000');
});
